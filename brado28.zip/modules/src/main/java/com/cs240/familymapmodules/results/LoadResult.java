package com.cs240.familymapmodules.results;

/**
 * The load result object of the /load api call
 */
public class LoadResult extends Result {
}
