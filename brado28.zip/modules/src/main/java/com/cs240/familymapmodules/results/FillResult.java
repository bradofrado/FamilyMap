package com.cs240.familymapmodules.results;

/**
 * The result object for the /fill/[username]/?generations api call
 */
public class FillResult extends Result {
}
