package com.cs240.familymapmodules.results;

/**
 * The result of the /clear api call
 */
public class ClearResult extends Result {
}
